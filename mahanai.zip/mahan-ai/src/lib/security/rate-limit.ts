/** Distributed sliding-window approximation using Upstash Redis REST when configured. */
export async function enforceRateLimit(key: string, limit = Number(process.env.CHAT_RATE_LIMIT_PER_MINUTE || 12), windowSeconds = 60) {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (url && token) {
    const redisKey = `mahan:rl:${key}`;
    const now = Date.now();
    const member = `${now}:${crypto.randomUUID()}`;
    const response = await fetch(`${url.replace(/\/$/, "")}/pipeline`, {
      method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }, cache: "no-store",
      body: JSON.stringify([
        ["ZREMRANGEBYSCORE", redisKey, "0", String(now - windowSeconds * 1000)],
        ["ZADD", redisKey, String(now), member],
        ["ZCARD", redisKey],
        ["PEXPIRE", redisKey, String(windowSeconds * 1000)]
      ]), signal: AbortSignal.timeout(3000)
    });
    if (!response.ok) throw new Error("RATE_LIMIT_STORE_UNAVAILABLE");
    const results = await response.json();
    const count = Number(results?.[2]?.result ?? limit + 1);
    return { success: count <= limit, remaining: Math.max(0, limit - count) };
  }
  // Single-process fallback is for local development only. Fail closed in production.
  if (process.env.NODE_ENV === "production") throw new Error("DISTRIBUTED_RATE_LIMIT_NOT_CONFIGURED");
  return localLimit(key, limit, windowSeconds);
}
const buckets = new Map<string, { count: number; resetAt: number }>();
function localLimit(key: string, max: number, windowSeconds: number) {
  const now = Date.now();
  const current = buckets.get(key);
  if (!current || current.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowSeconds * 1000 });
    return { success: true, remaining: max - 1 };
  }
  current.count++;
  return { success: current.count <= max, remaining: Math.max(0, max - current.count) };
}
