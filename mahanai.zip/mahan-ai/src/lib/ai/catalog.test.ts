import { describe, expect, it, vi, afterEach } from "vitest";

describe("model availability", () => {
  afterEach(() => vi.resetModules());

  it("exposes only enabled catalog entries in demo mode without claiming configuration", async () => {
    vi.stubEnv("DEMO_MODE", "true");
    const { getAvailableModels } = await import("./../../lib/models/catalog");
    const models = getAvailableModels();
    expect(models.length).toBeGreaterThan(0);
    expect(models.every(m => m.configured === false)).toBe(true);
  });

  it("does not expose unconfigured models outside demo mode", async () => {
    vi.stubEnv("DEMO_MODE", "false");
    vi.stubEnv("OPENAI_API_KEY", "");
    vi.stubEnv("GEMINI_API_KEY", "");
    vi.stubEnv("ANTHROPIC_API_KEY", "");
    vi.stubEnv("DEEPSEEK_API_KEY", "");
    vi.stubEnv("XAI_API_KEY", "");
    vi.stubEnv("MISTRAL_API_KEY", "");
    vi.stubEnv("OPENROUTER_API_KEY", "");
    vi.stubEnv("PERPLEXITY_API_KEY", "");
    const { getAvailableModels } = await import("./../../lib/models/catalog");
    expect(getAvailableModels()).toHaveLength(0);
  });
});
