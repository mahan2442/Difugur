"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Check, Sparkles } from "lucide-react";
const initialPlans = [
  { id: "free", name: "رایگان", price: "رایگان", dailyLimit: 20, description: "برای شروع و استفاده روزمره", features: ["سهمیه پایه روزانه", "مدل‌های متصل‌شده", "گفت‌وگوی متنی"] },
  { id: "plus", name: "Plus", price: "قیمت تنظیم نشده", dailyLimit: 100, description: "برای استفاده جدی‌تر", features: ["سهمیه بیشتر", "مدل‌های قدرتمندتر طبق تنظیمات", "۳۰ روز اشتراک پس از پرداخت موفق"] },
  { id: "pro", name: "Pro", price: "قیمت تنظیم نشده", dailyLimit: 300, description: "برای کارهای حرفه‌ای", features: ["سهمیه بالاتر", "مدل‌های منتخب", "۳۰ روز اشتراک پس از پرداخت موفق"] }
];
export default function PricingPage() {
  const [busy, setBusy] = useState<string | null>(null);
  const [notice, setNotice] = useState("");
  const [plans, setPlans] = useState(initialPlans);
  useEffect(() => { fetch("/api/plans", { cache: "no-store" }).then(async r => { const d = await r.json(); if (!r.ok) return; setPlans((d.plans ?? []).map((p: { id: string; name: string; price_irr: number; daily_message_limit: number }) => ({ ...initialPlans.find(x => x.id === p.id), id: p.id, name: p.name, dailyLimit: p.daily_message_limit, price: p.id === "free" ? "رایگان" : Number(p.price_irr) > 0 ? `${Number(p.price_irr).toLocaleString("fa-IR")} ریال / ۳۰ روز` : "قیمت تنظیم نشده" })).filter(Boolean) as typeof initialPlans); }).catch(() => {}); }, []);
  async function checkout(planId: string) {
    if (planId === "free") { window.location.href = "/login"; return; }
    setBusy(planId); setNotice("");
    try {
      const response = await fetch("/api/billing/checkout", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ planId }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "ساخت پرداخت ناموفق بود.");
      if (typeof data.paymentUrl !== "string" || !data.paymentUrl.startsWith("https://")) throw new Error("نشانی درگاه معتبر نیست.");
      window.location.assign(data.paymentUrl);
    } catch (error) { setNotice(error instanceof Error ? error.message : "خطای ناشناخته"); }
    finally { setBusy(null); }
  }
  return <main className="app-shell min-h-screen px-5 py-12"><div className="mx-auto max-w-5xl">
    <Link href="/" className="text-sm text-violet-500">← بازگشت به چت</Link>
    <div className="mb-10 mt-8 text-center"><div className="mb-3 flex justify-center text-violet-500"><Sparkles size={30}/></div><h1 className="mb-3 text-3xl font-black">پلن مناسب خودت را انتخاب کن</h1><p className="muted text-sm leading-7">برای خرید پلن، ابتدا وارد حساب شوید. قیمت پلن‌ها از پایگاه داده خوانده می‌شود و باید توسط مدیر تنظیم شده باشد.</p></div>
    {notice && <div role="alert" className="mb-5 rounded-xl border border-red-300 bg-red-50 p-4 text-sm text-red-700">{notice}</div>}
    <div className="grid gap-5 md:grid-cols-3">{plans.map((p, i) => <section key={p.id} className={`surface rounded-3xl p-6 ${i === 1 ? "border-violet-400 shadow-xl shadow-violet-500/10" : ""}`}><div className="mb-2 text-lg font-extrabold">{p.name}</div><p className="muted mb-6 text-sm">{p.description}</p><div className="mb-7 text-xl font-black">{p.price}</div><ul className="mb-8 space-y-4">{p.features.map(f => <li key={f} className="flex gap-2 text-sm"><Check size={17} className="shrink-0 text-emerald-500"/>{f}</li>)}</ul><p className="muted mb-4 text-xs">سقف روزانه: {p.dailyLimit.toLocaleString("fa-IR")} پیام</p><button disabled={busy !== null} onClick={() => void checkout(p.id)} className="ghost-btn w-full disabled:opacity-50">{busy === p.id ? "در حال اتصال به درگاه…" : p.id === "free" ? "شروع رایگان" : "خرید اشتراک"}</button></section>)}</div>
    <p className="muted mt-8 text-center text-xs leading-6">اشتراک فقط پس از تأیید سمت سرور درگاه فعال می‌شود. مبلغ به ریال و از جدول plans خوانده می‌شود.</p>
  </div></main>;
}
