"use client";

import { FormEvent, useEffect, useState } from "react";
import Link from "next/link";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";
import { ArrowRight, Mail } from "lucide-react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (new URLSearchParams(window.location.search).get("error") === "callback") {
      setMessage("تأیید ورود انجام نشد. دوباره لینک ورود بگیرید و مطمئن شوید Redirect URL در Supabase ثبت شده است.");
    }
  }, []);

  function getClient() {
    if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
      setMessage("ورود واقعی هنوز فعال نشده است. مدیر سایت باید تنظیمات Supabase را در Render وارد کند.");
      return null;
    }
    return createSupabaseBrowserClient();
  }

  async function signInGoogle() {
    try {
      const supabase = getClient();
      if (!supabase) return;
      setBusy(true);
      const { error } = await supabase.auth.signInWithOAuth({ provider: "google", options: { redirectTo: `${window.location.origin}/auth/callback?next=/` } });
      if (error) setMessage(`ورود با Google انجام نشد: ${error.message}`);
    } catch (error) { setMessage(`شروع ورود ممکن نشد: ${error instanceof Error ? error.message : "خطای نامشخص"}`); }
    finally { setBusy(false); }
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    try {
      const supabase = getClient();
      if (!supabase) return;
      setBusy(true);
      const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: `${window.location.origin}/auth/callback?next=/` } });
      setMessage(error ? `ارسال لینک ورود انجام نشد: ${error.message}` : "لینک ورود ارسال شد. ایمیل را باز کنید و همان مرورگر را برای برگشت به سایت استفاده کنید.");
    } catch (error) { setMessage(`ارسال لینک ورود ممکن نشد: ${error instanceof Error ? error.message : "خطای نامشخص"}`); }
    finally { setBusy(false); }
  }

  return <main className="app-shell flex min-h-screen items-center justify-center p-4 sm:p-6">
    <section className="surface w-full max-w-md rounded-[28px] border p-6 shadow-xl shadow-black/[.04] sm:p-8">
      <Link href="/" className="mb-8 inline-flex items-center gap-3 text-sm muted"><ArrowRight size={16}/> بازگشت به Mahan AI</Link>
      <div className="mb-7 flex items-center gap-3">
        <div className="mahan-logo flex h-12 w-12 items-center justify-center rounded-2xl border p-2"><svg viewBox="0 0 100 82" role="img" aria-label="Mahan AI"><path d="M12 65 31 23Q35 14 40 24L52 47Q55 53 60 45L74 20Q78 12 83 22L94 49" fill="none" stroke="currentColor" strokeWidth="15" strokeLinecap="round" strokeLinejoin="round"/></svg></div>
        <div><div className="text-xl font-extrabold tracking-tight">Mahan AI</div><div className="muted mt-1 text-xs">یک حساب برای فضای هوش مصنوعی شما</div></div>
      </div>
      <h1 className="mb-2 text-2xl font-black">ورود یا ثبت‌نام</h1>
      <p className="muted mb-6 text-sm leading-7">برای ذخیره گفتگوها و استفاده از حساب خود وارد شوید.</p>
      <button type="button" onClick={signInGoogle} disabled={busy} className="surface mb-3 flex w-full items-center justify-center gap-3 rounded-full border px-4 py-3 text-sm font-semibold transition hover:bg-black/[.04] disabled:opacity-50 dark:hover:bg-white/[.05]"><span className="flex h-5 w-5 items-center justify-center rounded-full border text-xs font-bold">G</span> ادامه با Google</button>
      <div className="my-5 flex items-center gap-3 muted text-xs"><span className="h-px flex-1" style={{background:"var(--line)"}}/><span>یا با ایمیل</span><span className="h-px flex-1" style={{background:"var(--line)"}}/></div>
      <form onSubmit={submit} className="space-y-4">
        <label className="block text-sm font-semibold">آدرس ایمیل<div className="surface mt-2 flex items-center gap-2 rounded-2xl border px-3"><Mail size={17} className="muted"/><input required type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full bg-transparent px-1 py-3 text-left outline-none" dir="ltr" placeholder="you@example.com"/></div></label>
        <button disabled={busy} type="submit" className="primary-btn w-full justify-center rounded-full py-3 disabled:opacity-50">{busy ? "لطفاً صبر کنید…" : "ادامه با ایمیل"}</button>
      </form>
      {message && <p role="status" className="surface mt-4 rounded-2xl border p-3 text-sm leading-6">{message}</p>}
      <p className="muted mt-6 text-center text-xs leading-6">با ادامه، شرایط استفاده و حریم خصوصی را می‌پذیرید.</p>
    </section>
  </main>;
}
