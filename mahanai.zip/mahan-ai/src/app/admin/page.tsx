import Link from "next/link";
import { redirect } from "next/navigation";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import AdminDashboard from "./admin-dashboard";
export const dynamic = "force-dynamic";
export default async function AdminPage() {
  if (process.env.DEMO_MODE === "true") redirect("/");
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).maybeSingle();
  if (profile?.role !== "admin") redirect("/");
  return <main className="app-shell min-h-screen p-6 md:p-10"><div className="mx-auto max-w-6xl"><Link href="/" className="text-sm text-violet-500">← بازگشت</Link><h1 className="my-6 text-3xl font-black">پنل مدیریت Mahan AI</h1><AdminDashboard/></div></main>;
}
