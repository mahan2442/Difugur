import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Mahan AI | دستیار هوش مصنوعی چندمدلی",
  description: "یک فضای یکپارچه برای کار با مدل‌های هوش مصنوعی مختلف.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="fa" dir="rtl" suppressHydrationWarning>
    <body>{children}</body>
  </html>;
}
