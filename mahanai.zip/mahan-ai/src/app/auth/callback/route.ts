import { NextResponse, type NextRequest } from "next/server";
import { createServerClient } from "@supabase/ssr";

export async function GET(request: NextRequest) {
  const requestUrl = new URL(request.url);
  const code = requestUrl.searchParams.get("code");
  const next = requestUrl.searchParams.get("next");
  const destination = next && next.startsWith("/") && !next.startsWith("//") ? next : "/";
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!code || !supabaseUrl || !supabaseKey) {
    return NextResponse.redirect(new URL("/login?error=callback", requestUrl.origin));
  }

  // Keep Supabase's PKCE/session cookies on the final redirect response.
  const cookieResponse = NextResponse.next({ request });
  const supabase = createServerClient(supabaseUrl, supabaseKey, {
    cookies: {
      getAll: () => request.cookies.getAll(),
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
        cookiesToSet.forEach(({ name, value, options }) => cookieResponse.cookies.set(name, value, options));
      },
    },
  });

  const { error } = await supabase.auth.exchangeCodeForSession(code);
  if (error) {
    console.error("auth_callback_exchange_failed", { message: error.message });
    return NextResponse.redirect(new URL("/login?error=callback", requestUrl.origin));
  }

  const redirectResponse = NextResponse.redirect(new URL(destination, requestUrl.origin));
  cookieResponse.cookies.getAll().forEach(cookie => redirectResponse.cookies.set(cookie));
  return redirectResponse;
}
