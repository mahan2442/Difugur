import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { verifyPayment } from "@/lib/payments/zarinpal";
import { NextRequest, NextResponse } from "next/server";
export const runtime = "nodejs";
export async function GET(request: NextRequest) {
  const paymentId = request.nextUrl.searchParams.get("paymentId");
  const authority = request.nextUrl.searchParams.get("Authority");
  const status = request.nextUrl.searchParams.get("Status");
  const base = (process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000").replace(/\/$/, "");
  const fail = (reason: string) => NextResponse.redirect(new URL(`/pricing?payment=${encodeURIComponent(reason)}`, base));
  if (!paymentId || !authority || status !== "OK") return fail("cancelled");
  const admin = createSupabaseAdminClient();
  const { data: payment, error } = await admin.from("payments").select("id,user_id,plan_id,amount_irr,status,authority,subscription_id").eq("id", paymentId).maybeSingle();
  if (error || !payment || payment.authority !== authority) return fail("invalid");
  if (payment.status === "paid") return NextResponse.redirect(new URL("/pricing?payment=success", base));
  if (payment.status !== "pending") return fail("invalid");
  try {
    const verification = await verifyPayment(authority, Number(payment.amount_irr));
    if (!verification.verified) {
      await admin.from("payments").update({ status: "failed" }).eq("id", payment.id).eq("status", "pending");
      return fail("failed");
    }
    // Atomic database function makes payment, subscription and plan activation one transaction.
    const { data: activated, error: activationError } = await admin.rpc("activate_verified_payment", { p_payment_id: payment.id, p_ref_id: verification.refId ?? null });
    if (activationError) {
      console.error("payment_activation_failed", { paymentId: payment.id });
      return fail("retry");
    }
    if (activated !== true) {
      const { data: fresh } = await admin.from("payments").select("status").eq("id", payment.id).maybeSingle();
      return fresh?.status === "paid" ? NextResponse.redirect(new URL("/pricing?payment=success", base)) : fail("retry");
    }
    return NextResponse.redirect(new URL("/pricing?payment=success", base));
  } catch (e) {
    console.error("zarinpal_verify_failed", { paymentId: payment.id, code: e instanceof Error ? e.message.split(":")[0] : "UNKNOWN" });
    return fail("retry");
  }
}
