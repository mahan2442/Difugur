import { z } from "zod";
import { requireUser } from "@/lib/auth/require-user";
const paramsSchema = z.object({ id: z.string().uuid() });
export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  if (process.env.DEMO_MODE === "true") return Response.json({ ok: true, demo: true });
  const auth = await requireUser();
  if (!auth.user) return auth.response!;
  const params = paramsSchema.safeParse(await context.params);
  if (!params.success) return Response.json({ error: "شناسه نامعتبر است." }, { status: 400 });
  const { error, count } = await auth.supabase.from("conversations").delete({ count: "exact" }).eq("id", params.data.id).eq("user_id", auth.user.id);
  if (error) return Response.json({ error: "حذف گفت‌وگو ناموفق بود." }, { status: 500 });
  if (count === 0) return Response.json({ error: "گفت‌وگو پیدا نشد." }, { status: 404 });
  return Response.json({ ok: true });
}
