import { z } from "zod";
import { requireUser } from "@/lib/auth/require-user";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
const schema = z.object({ id: z.enum(["free", "plus", "pro"]), price_irr: z.number().int().min(0).max(1000000000000), daily_message_limit: z.number().int().min(0).max(100000), monthly_token_limit: z.number().int().min(0).max(1000000000), is_active: z.boolean() });
export async function PATCH(request: Request) {
  if (process.env.DEMO_MODE === "true") return Response.json({ error: "پنل مدیریت در حالت نمایشی در دسترس نیست." }, { status: 409 });
  const auth = await requireUser();
  if (!auth.user) return auth.response!;
  const { data: profile } = await auth.supabase.from("profiles").select("role").eq("id", auth.user.id).maybeSingle();
  if (profile?.role !== "admin") return Response.json({ error: "دسترسی مدیر لازم است." }, { status: 403 });
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "مقادیر پلن نامعتبر هستند." }, { status: 400 });
  if (parsed.data.id === "free" && parsed.data.price_irr !== 0) return Response.json({ error: "پلن رایگان باید قیمت صفر داشته باشد." }, { status: 400 });
  const admin = createSupabaseAdminClient();
  const { id, ...changes } = parsed.data;
  const { error } = await admin.from("plans").update({ ...changes, updated_at: new Date().toISOString() }).eq("id", id);
  if (error) return Response.json({ error: "ذخیره تنظیمات پلن ناموفق بود." }, { status: 500 });
  await admin.from("admin_audit_logs").insert({ actor_user_id: auth.user.id, action: "plan.updated", target_type: "plan", target_id: id, metadata: changes });
  return Response.json({ ok: true });
}
